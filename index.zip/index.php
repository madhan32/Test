<html>
<head>
<title>
My Page
</title>
</head>
<body background-color:#EEEEEE;>
<?php

echo "Updated Hello world";


?>
</body>
</html>

